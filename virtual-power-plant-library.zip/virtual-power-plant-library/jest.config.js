module.exports = {
    transform: {
        '^.+\\.ts?$': 'ts-jest',
    },
};